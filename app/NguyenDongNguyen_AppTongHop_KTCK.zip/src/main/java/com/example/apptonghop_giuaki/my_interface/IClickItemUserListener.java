package com.example.apptonghop_giuaki.my_interface;

import com.example.apptonghop_giuaki.fragment.Car;

public interface IClickItemUserListener {
    void onClickItemUser(Car computer);
}
